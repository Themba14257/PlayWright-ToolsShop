 export const BASE_URL = 'https://practicesoftwaretesting.com/';
